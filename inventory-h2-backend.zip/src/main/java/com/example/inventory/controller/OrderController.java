package com.example.inventory.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.example.inventory.entity.Order;
import com.example.inventory.service.OrderService;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
@CrossOrigin
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public Order placeOrder(@RequestParam Long productId,
                            @RequestParam int quantity) {
        return orderService.placeOrder(productId, quantity);
    }
}
