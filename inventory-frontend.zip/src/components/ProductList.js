import React, { useEffect, useState } from "react";
import axios from "axios";

function ProductList() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const response = await axios.get("http://localhost:8080/products");
    setProducts(response.data);
  };

  return (
    <div>
      <h3>Product List</h3>
      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} - {p.quantity} units - ₹{p.price}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductList;
