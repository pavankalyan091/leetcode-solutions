import React, { useState } from "react";
import axios from "axios";

function ProductForm() {
  const [product, setProduct] = useState({
    name: "",
    price: "",
    quantity: "",
    category: ""
  });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/products", product);
    alert("Product Added");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>Add Product</h3>
      <input name="name" placeholder="Name" onChange={handleChange} /><br/>
      <input name="price" placeholder="Price" onChange={handleChange} /><br/>
      <input name="quantity" placeholder="Quantity" onChange={handleChange} /><br/>
      <input name="category" placeholder="Category" onChange={handleChange} /><br/>
      <button type="submit">Add</button>
    </form>
  );
}

export default ProductForm;
