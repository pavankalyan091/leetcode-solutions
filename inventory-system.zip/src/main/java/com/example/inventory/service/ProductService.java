package com.example.inventory.service;

import org.springframework.stereotype.Service;
import java.util.List;
import lombok.RequiredArgsConstructor;
import com.example.inventory.entity.Product;
import com.example.inventory.repository.ProductRepository;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }
}
